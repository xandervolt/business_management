Yet another tree table.

![example](https://raw.githubusercontent.com/martinsbalodis/jquery-treetable/master/treetable.png)

```js
$(function() {
	$("table").treetable();
});
```